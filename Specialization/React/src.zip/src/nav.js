import './nav.css';
import React from 'react';
function Nav(){
    return(
        <div>
        {/* <div className='nav'>
        <nav>
          <a>Home</a>
          <a>About Us</a>
          <a>Galery</a>
          <a>Login</a>
          <a>Contact Us</a>
          <div className='animation start-home'></div>
        </nav>
        </div> */}
        </div>
    )
}
export default Nav;