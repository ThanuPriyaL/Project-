import React, { Component } from 'react';
import './about.css';
function About()
{
return(
<div>

<div class="about-section" >
<div class="inner-container">
<h1>About Us</h1>
<p>Flowers are beautiful things, and they make a perfect gift for someone you care about.Flowers did not always exist; they first appeared 140 million years ago. Before that, ferns and cone bearing trees dominated the earth.The largest Flower in the world is the flower of the Puya raimondii, which has a flower stalk 35,000 feet tall and bears over 8,000 white flowers.Several centuries ago in Holland, tulips were more valuable than gold.</p>
</div>
<div class="inner-container1">
<h1>Contact Us</h1>
<form>
<div className='text'>
<label htmlFor="firstname">Drop a Message</label>
<span></span>
<input type="text"required />
</div>
<div>
<input type="submit" value="Submit" />
</div>
</form>
</div>

</div>
</div>

)
}
export default About