
import React, { Component } from 'react';
import axios from 'axios';
import './register.css';
class Register extends Component {
constructor(props) {
super(props);
this.state = {
firstname:'',
lastname:'',
email:'',
mobile:'',
pass:'',
cpass:'' }
}
handleChange = event => {
this.setState({ [event.target.name]: event.target.value })
}
handleSubmit = event => {
// event.preventDefault()
axios.post('http://localhost:8081/saveuser', this.state)
.then(res => {
console.log(res.data)
})
.catch(err => {
console.log(err)
})
}
render() {
const { firstname, lastname,email,mobile,pass,cpass } = this.state
return (

<div className='center'>
<form onSubmit={this.handleSubmit}>
<div id="text" className='text'>
<label htmlFor="firstname">First Name</label>
<span></span>
<input type="text" name="firstname" id="fname" value={firstname} required onChange={this.handleChange} />
</div>

<div className='text'>
<label htmlFor="lastname">Last Name</label>
<span></span>
<input type="text" name="lastname" id="lname" value={lastname} required onChange={this.handleChange} />
</div>

<div className='text'>
<label htmlFor="email">Email</label>
<span></span>
<input type="email" name="email" id="email" value={email} required onChange={this.handleChange} />
</div>

<div  className='text'>
<label htmlFor="mobile">Mobile Number</label>
<span></span>
<input type="tel" name="mobile" id="mobile" value={mobile} required onChange={this.handleChange} />
</div>

<div className='text'>
<label htmlFor="password">Password</label>
<span></span>
<input type="password" name="pass" id="password" value={pass} required onChange={this.handleChange} />
</div>
<div className='text'>
<label htmlFor="cpassword">Confirm Password</label>
<span></span>
<input type="password" name="cpass" id="cpassword" value={cpass} required onChange={this.handleChange} />
</div>
<div>
<input type="submit" value="Register" />
</div>
</form>
</div>
);
}
}
export default Register;

