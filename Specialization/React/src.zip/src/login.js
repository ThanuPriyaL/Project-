import React, { Component } from 'react';
function Login(){
    return(
  <div className='center'>
<form>
<div  className='text'>
<label htmlFor="mobile">Mobile Number</label>
<span></span>
<input type="tel" name="mobile" id="mobile" required />
</div>

<div className='text'>
<label htmlFor="email">Email</label>
<span></span>
<input type="email" name="email" id="email" required />
</div>

<div className='text'>
<label htmlFor="password">Password</label>
<span></span>
<input type="password" name="pass" id="password" required  />
</div>
<div>
<input type="submit" value="Login" />
</div>
</form>
</div>
    );
}
export default Login;