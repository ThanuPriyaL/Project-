import React from 'react';
import { useCart } from "react-use-cart";
import './cart.css';

const Cart = () => {
    const {
        isEmpty,
        totalUniqueItems,
        items,
        totalItems,
        cartTotal,
        updateItemQuantity,
        removeItem,
        emptyCart,

    } = useCart();
    // if (isEmpty) return <h1 className="text-center">Your Cart is Empty</h1>
    return(
        <section className="py-4 container">
        <div id="color" className="row justify-content-center">
            <div className="col-12">
            {/* <h5>Cart ({totalUniqueItems}) total Items: ({totalItems})</h5> */}
            <table className="table table-light table-hover m-0">
                
<tbody>
                
                {items.map((item,index)=>{
                    return(
                    <tr id='cart' key={index}>
                        <td id='cart' >
                            <img src={item.img} style={{height:'6rem'}}/>
                        </td>
                        {/* <td className="col-auto col-lg-8"><button id="buy" className="btn btn-primary m-2">Buy Now</button></td> */}
                        <td id='cart' >{item.title}</td>
                        <td id='cart' >{item.price}</td>
                        <td id='cart' >Quantity ({item.quantity})/Kg</td>
                        <td id='cart' >

                            <button  id="ab"  className="btn btn-info ms-2" 
                            onClick={() => updateItemQuantity(item.id,item.quantity - 1 )}
                            >-</button>
                            <button id="ab" className="btn btn-info ms-2"
                            onClick={() => updateItemQuantity(item.id,item.quantity + 1 )}
                            >+</button>
                            <button id="remove" className="btn btn-danger ms-2"
                            onClick={() => removeItem(item.id)}
                            >Remove Item</button>
                        </td>

                    </tr>
                    )
                    
                })}
                
                </tbody>
            </table>
            </div>
            <div className="col-auto md-auto">
                <h4 id="price">Total Price</h4> 

            </div>
            <div className="col-auto col-lg-8">
                <h4 id="price">₹.{cartTotal}</h4> </div>
            <div className="col-auto ms-auto">
                {/* <button className="btn btn-danger m-2"
                onClick={() => emptyCart()}
                >Clear Cart</button> */}
                <button id="buy" className="btn btn-primary m-2">Buy Now</button>

            </div>
        </div>
        </section>
    );
};
export default Cart;