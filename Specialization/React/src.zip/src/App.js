// import React from 'react';
// import './App.css';
// import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
// import Home from "./Home";
// import Cart from "./Cart";
// import {CartProvider } from "react-use-cart"
// import Nav from "./nav";
// import Footer from "./footer";
// function App() {
//   return (
//     <>
//     <Nav></Nav>
//     <CartProvider>
//     <Home/>
//     <Cart/>
//     </CartProvider>
//     <Footer></Footer>
//     </>
    
//   );
// }

// export default App;


import React from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Home from "./Home";
import Register from './register';
import Login from './login';
import Cart from './Cart';
import About from './about';
import {CartProvider } from "react-use-cart";
import Nav from "./nav";
import Footer from "./footer";
import { BrowserRouter as Router,Switch, Route ,Link} from 'react-router-dom';
function App() {
return (
<div>

<Router>
<div>
<div class="navbar">
<nav>

<a><Link to={'/'}>Home</Link></a>
{/* <a><Link to={'/home'}>Home</Link></a> */}
<a><Link to={'/about'}>About</Link></a>
<a><Link to={'/login'}>Login</Link></a>
<a><Link to={'/register'}>Register</Link></a>
<a><Link to={'/cart'}>Cart</Link></a>
<div className='animation start-home'></div>
</nav>
</div>
<Switch>
<CartProvider>
<Route exact path='/login' component={Login}/>
<Route exact path='/' component={Home}/>
<Route exact path='/about' component={About}/>
<Route exact path='/register' component={Register}/>
<Route exact path='/cart' component={Cart}/>

</CartProvider>
</Switch>

</div>

</Router>
</div>

);
}



export default App;