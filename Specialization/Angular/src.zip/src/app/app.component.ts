import { Component } from '@angular/core';
import { UserService } from './user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'router-app';
  users:any=[];
  constructor(private user:UserService){
}
ngOnInit():void{
this.user.getAllUser().subscribe((data)=>
{
this.users=data;
console.log(data);
})
}
}
