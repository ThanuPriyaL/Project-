import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class DataService  {
  getData(msg: any) {
    throw new Error('Method not implemented.');
  }
  message:any[]=[];
  constructor() { }

  dataServe(msg:any){
    // console.log("this message is from Data Service"+msg)
    this.message.push(msg);
    //this.log.check(msg);//calling log service
  }
  callData():any{
    return this.message;
  }

}